Sample DTM gives height data that you should use to shape your terrain.

x and y give coordinates in meters using eastings and northings on teh British national grid.
DTM - stands or Digita Terrain Model, and gives the height of the terrain in meters at the x-y cordinates

SampleLULC gives the land cover type at each x-y coordinate

x and y see above
Code - a numeric code for the landcover tyoe
Class - the code translated into English

Some information on the classes can be found here: https://www.ceh.ac.uk/sites/default/files/LCM2015_Dataset_Documentation_22May2017.pdf 
However, we don’t expect you to be experts on the species that make up each habitat, this expertise will
be provided by UKCEH staff if you are awarded the position.